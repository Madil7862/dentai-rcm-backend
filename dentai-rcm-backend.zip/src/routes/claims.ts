import { Router } from 'express';

const router = Router();

let claims = [
    { id: 1, patientName: 'John Doe', claimId: 'CLM001', amount: 250, status: 'Pending', date: '2025-08-08' }
];

router.get('/', (req, res) => {
    res.json(claims);
});

router.post('/', (req, res) => {
    const newClaim = { id: claims.length + 1, ...req.body };
    claims.push(newClaim);
    res.status(201).json(newClaim);
});

export default router;
